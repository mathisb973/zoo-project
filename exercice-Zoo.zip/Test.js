/*Ajout de chimpanzé*/
var AddChimpanze, AddChimpanze1;
var btnChimpAdd = document.getElementById('AddChimpanzes');
btnChimpAdd.addEventListener('click', AddChimp);
function AddChimp() {
    if (btnChimpAdd.value === 'Ajouter des chimpanzés') {
        AddChimpanze=   prompt('','Combien de chimpanzé ajouter ?');
        AddChimpanze1 =parseInt(AddChimpanze);
        Chimpanze1 = AddChimpanze1 + Chimpanze1;
        CoutChimp = 3 * CoutVeg * Chimpanze1;
    } else {
    }
    document.getElementById("ChimpanId").innerHTML = Chimpanze1;
    document.getElementById("idCoutChamp").innerHTML = CoutChimp +' €';
}
/*Fin Ajout de chimpanzé*/
/*Suppr de chimpanzé*/
var SupprChimpanze, SupprChimpanze1;
var btnChimpsuppr = document.getElementById('SuprChimpanzes');
btnChimpsuppr.addEventListener('click', SuprChimp);
function SuprChimp() {
    if (btnChimpsuppr.value === 'Retirer des chimpanzés') {
        SupprChimpanze=   prompt('','Combien de chimpanzé retirer ?');
        SupprChimpanze1 =parseInt(SupprChimpanze);
        Chimpanze1 = Chimpanze1 - SupprChimpanze1;
        CoutChimp = 3 * CoutVeg * Chimpanze1;
    } else {
    }
    document.getElementById("ChimpanId").innerHTML = Chimpanze1;
    document.getElementById("idCoutChamp").innerHTML = CoutChimp +' €';
    if (Chimpanze1<0){
        document.location.href="file:///C:/Users/romai/Documents/WIS%20-%203/Algorithmique%20et%20Angular/Zoo/Zoo.html";
    }
}
/*Fin Suppr de chimpanzé*/


/*Ajout de Tigres*/
var AddTigre, AddTigre1;
var btnTigreAdd = document.getElementById('AddTigres');
btnTigreAdd.addEventListener('click', AddTigre);
function AddTigre() {
    if (btnTigreAdd.value === 'Ajouter des tigres') {
        AddTigre=   prompt('','Combien de tigres ajouter ?');
        AddTigre1 =parseInt(AddTigre);
        Tigre1 = AddTigre1 + Tigre1;
    } else {
    }
    document.getElementById("TigreId").innerHTML = Tigre1;
}
/*Fin Ajout de Tigres*/
/*Suppr de Tigres*/
var SupprTigre, SupprTigre1;
var btnTigressuppr = document.getElementById('SuprTigres');
btnTigressuppr.addEventListener('click', SuprTigre);
function SuprTigre() {
    if (btnTigressuppr.value === 'Retirer des tigres') {
        SupprTigre=   prompt('','Combien de tigres retirer ?');
        SupprTigre1 =parseInt(SupprTigre);
        Tigre1 = Tigre1 - SupprTigre1;
    } else {
    }
    document.getElementById("TigreId").innerHTML = Tigre1;
    if (Tigre1<0){
        document.location.href="file:///C:/Users/romai/Documents/WIS%20-%203/Algorithmique%20et%20Angular/Zoo/Zoo.html";
    }
}
/*Fin Suppr de Tigres*/

/*Ajout de Boa*/
var AddBoa, AddBoa1;
var btnBoaAdd = document.getElementById('AddBoa');
btnBoaAdd.addEventListener('click', AddBoa);
function AddBoa() {
    if (btnBoaAdd.value === 'Ajouter des boas') {
        AddBoa=   prompt('','Combien de boas ajouter ?');
        AddBoa1 =parseInt(AddBoa);
        Boa1 = AddBoa1 + Boa1;
    } else {
    }
    document.getElementById("BoaId").innerHTML = Boa1;
}
/*Fin Ajout de Boa*/
/*Suppr de Boa*/
var SupprBoa, SupprBoa1;
var btnBoasuppr = document.getElementById('Suprboa');
btnBoasuppr.addEventListener('click', Suprboa);
function Suprboa() {
    if (btnBoasuppr.value === 'Retirer des boas') {
        SupprBoa=   prompt('','Combien de boas retirer ?');
        SupprBoa1 =parseInt(SupprBoa);
        Boa1 = Boa1 - SupprBoa1;
    } else {
    }
    document.getElementById("BoaId").innerHTML = Boa1;
    if (Boa1<0){
        document.location.href="file:///C:/Users/romai/Documents/WIS%20-%203/Algorithmique%20et%20Angular/Zoo/Zoo.html";
    }
}
/*Fin Suppr de Boa*/
